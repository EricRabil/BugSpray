<?php
$settings = array(
		"maintenance" => false,
		//Put the file location of the maintenance page from the perspective of /include/index.php
		"maintenancedir" => "../pages/maintenance.php",
		"projectname" => "Backbones Project",
		"mobileurl" => "m.contoso.com",
		"showErrors" => false
);