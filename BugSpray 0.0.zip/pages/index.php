<?php
$example = array();
$example["title"] = "This is an example!";
$context = array();
$context["example"] = $example;
$context["settings"] = $settings;
$styles = array();
$scripts = array("/js/start.js");
render('index.phtml', 'Backbones', $context, $styles, $scripts);